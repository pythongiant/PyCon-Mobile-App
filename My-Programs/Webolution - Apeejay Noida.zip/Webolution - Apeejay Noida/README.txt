This is the prelim entry for webolution.
School Name: Apeejay School, Noida
School Code: apjsnoi16
Name: Ansh Arora
PS: Looks best on 1366 x 768 resolution