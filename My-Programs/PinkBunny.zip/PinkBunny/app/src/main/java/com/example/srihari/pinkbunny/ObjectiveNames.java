package com.example.srihari.pinkbunny;

/**
 * Created by srihari on 20/10/17.
 */

public class ObjectiveNames {
    static String[] obejctiveName={
            "Make one new friend",
            "Watch 5 comedy movies in a  week ",
            "Tweet or post on FaceBook-'#IamAFurryBunny'",
            "Post 2 memes on any social network",
            "Write 5 jokes in a notebook",
            "Go to your favourite restraunt with your friend",
            "Write your best trait on a Peice of paper",
            "Feed a stray animal",
            "Learn something new",
            "Dance to a song",
            "Write a poem/song about yourself. ",
            "Go shopping with a friend",
            "Listen to one of the following songs \n 1)Happy By Pharell Williams \n 2)Best Day Of My Life By American Authors \n 3)The Twist - Chubby Checker",
            "Buy some new clothes for yourself","Watch one of these TED Talks \n 1)Dan Gilbert- Science of Happiness \n 2)James Veitch. This is what happens when you reply to spam email.\n 3) Ze Frank. Nerdcore comedy",
            "Host a Party and call all your friends",
            "Make your favourite dish ",
            "Read the Bone series",
            "Write a poem/song (happy ones)",
            "Go shopping with a friend",
            "Go to the movies. Preferrably with your Parents or your friends",
            "Play a random instrument in front of someone \n Or \n Learn a new Instrument.",
            "Share 10 new facts on social media",
            "Exersize for 30 minutes ",
            "Draw a painting ",
            "Make something healthy for yourself",
            "Learn 10 new words from the dictionary.",
            "Go for Vacation outside the city",
            "Go to a nearby library and read a new book ",
            "Play your favourite sport for atleast an hour",
            ""


    };
    public static String AllNames(int listNum){
        return obejctiveName[listNum-1];
    }
}
