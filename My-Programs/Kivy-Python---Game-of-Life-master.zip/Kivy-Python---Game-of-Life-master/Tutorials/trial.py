x = [0, 1, 2, 3, 4]
y = ['a', 'b', 'c', 'd', 'e']

for i, j in zip(x, y):
	print i
	print j
