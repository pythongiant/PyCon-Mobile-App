# Silico-Battles-2017-CSI-WebDesign
Repository for CSI's submission for Web Designing in Silico Battles - 2017
